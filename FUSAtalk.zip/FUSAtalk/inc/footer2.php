<!-- navbar -->
<nav class="navbar">
    <!--<a href="index.php" class="navbar-brand">
        <img src="FUSAtalk-webp/FUSAtalkC.webp" alt="FUSAtalk Logo" class="logo">
    </a>-->
</nav>

<style>
    .navbar {
        background: linear-gradient(to top right, rgba(53, 79, 166, 1), rgba(53, 79, 166, 1)); /* Linear gradient background */
        padding: 0px; /* Optional: Adjust padding for better spacing */
    }

    .navbar-brand {
        display: flex;
        align-items: center;
        gap: 8px; /* Space between logo and any potential text */
    }

    .logo {
        width: 30px; /* Adjust size of logo */
        height: 30px;
    }
</style>
</body>
</html>
