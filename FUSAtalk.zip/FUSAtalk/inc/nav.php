  <!-- navbar -->
  <nav class="navbar">
    <a href="index.php" class="navbar-brand">
      <img src="FUSAtalk-webp/FUSAtalkC.webp" alt="FUSAtalk Logo" class="logo"> FUSAtalk
    </a>
    <!-- Links -->
    <!--<ul class="list">
      <li class="nav-item">
        <a class="nav-link login" href="login.php">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link signup" href="signup.php">Signup</a>
      </li>
    </ul>-->
    <style>
      .navbar-brand {
    display: flex;
    align-items: center;
    gap: 8px; /* Add space between logo and text */
}

.logo {
    width: 30px; /* Adjust size as needed */
    height: 30px;
}
</style>
</nav>
</body>
</html>