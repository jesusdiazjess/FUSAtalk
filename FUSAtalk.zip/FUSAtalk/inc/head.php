<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Favicon -->
  <link rel="icon" href="FUSAtalk-webp/FUSAtalkC.webp" type="image/x-icon">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="description" content="Home Page" />
    <title>FUSAtalk – The Fast, Reliable Messenger That Brings Everyone Together.</title>
    <!-- css and bootstrap -->
    <link rel="stylesheet" href="./css/style.css" />
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <!-- boostrap icon and jqouery -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <!-- chart.css -->
    <!-- js files -->
    <script src="./js/jquery.js"></script>
    <!-- icon script -->
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
  </head>
<body>